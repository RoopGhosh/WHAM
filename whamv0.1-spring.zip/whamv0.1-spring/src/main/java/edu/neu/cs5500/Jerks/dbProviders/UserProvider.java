package edu.neu.cs5500.Jerks.dbProviders;

/* Author: Sandeep Ramamoorthy
 * Creation Date: 11/02/2015 6:04 AM EST
 * Description: All user related database calls and methods goes into this class 
 * */
public class UserProvider {

}
