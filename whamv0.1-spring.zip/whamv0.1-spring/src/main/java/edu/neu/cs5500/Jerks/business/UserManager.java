package edu.neu.cs5500.Jerks.business;

/* Author: Sandeep Ramamoorthy
 * Creation Date: 11/02/2015 6:04 AM EST
 * Description: All business logic related to user goes into this class 
 * */
public class UserManager {

	//Remove placeholder 
}
